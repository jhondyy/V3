// ANC Lab Pro native engine: Oboe duplex (mic -> safe gain -> headphones) + offline FxLMS simulation.
#include <jni.h>
#include <oboe/Oboe.h>
#include <atomic>
#include <cmath>
#include <cstring>
#include <memory>
#include <random>
#include <vector>
#include "anc_dsp.h"
using namespace oboe;

static constexpr int kMax = 16384;

struct Engine : AudioStreamDataCallback, AudioStreamErrorCallback {
    std::shared_ptr<AudioStream> out, in;
    anc::Biquad hp; anc::Safety safety;
    std::vector<float> inBuf = std::vector<float>(kMax, 0.f);
    std::atomic<float> gain{0.f}, rms{0.f}, peak{0.f};
    std::atomic<bool> running{false}, fault{false};
    std::atomic<uint64_t> inShort{0}, inClip{0};
    anc::NarrowbandAnc nb; std::atomic<int> mode{1}, request{0}; std::atomic<float> freq{200.f};
    float snap[1024] = {0}; std::atomic<int> pos{0}; bool unprocessed = false;

    DataCallbackResult onAudioReady(AudioStream* s, void* data, int32_t n) override {
        float* o = static_cast<float*>(data); int ch = s->getChannelCount();
        std::memset(o, 0, sizeof(float) * n * ch);
        if (!running.load() || !in) return DataCallbackResult::Continue;
        int m = n > kMax ? kMax : n; int got = 0;
        auto r = in->read(inBuf.data(), m, 0);                // non-blocking
        if (r.error() == Result::OK) got = r.value();
        if (got < m) { inShort++; std::memset(inBuf.data() + got, 0, sizeof(float) * (m - got)); }
        float sr = float(s->getSampleRate());
        int rq = request.exchange(0);
        if (rq == 1) { safety.configure(0.3f, 48, 1.0f, sr); nb.configure(sr, freq.load(), 3e-4f); nb.startCal(); mode = 2; }
        else if (rq == 2 && nb.cal == anc::NarrowbandAnc::OK) { nb.startAnc(&safety); mode = 3; }
        else if (rq == 3) { safety.configure(0.3f, 48, 1.0f, sr); mode = 1; }
        int md = mode.load();
        float g = gain.load(), pk = 0, acc = 0; int p = pos.load();
        for (int i = 0; i < m; ++i) {
            float raw = inBuf[i], ax = std::fabs(raw);
            if (ax >= 0.98f) inClip++;
            if (ax > pk) pk = ax;
            float x = hp.process(raw); acc += x * x;
            snap[p & 1023] = x; ++p;
            float y;
            if (md == 2) { y = nb.stepCal(x); if (nb.cal != anc::NarrowbandAnc::RUNNING) { md = 1; mode = 1; } }
            else if (md == 3) y = nb.stepAnc(x);
            else y = x * g;                                   // monitor (bypass) with safe gain
            y = safety.process(y);
            for (int c = 0; c < ch; ++c) o[i * ch + c] = y;
        }
        pos.store(p);
        rms.store(std::sqrt(acc / (m > 0 ? m : 1))); peak.store(pk);
        return DataCallbackResult::Continue;
    }
    void onErrorAfterClose(AudioStream*, Result) override { fault = true; running = false; }

    int start(int outId, int inId, float g) {
        stop(); fault = false; safety.reset(); nb = anc::NarrowbandAnc(); mode = 1; request = 0; inShort = 0; inClip = 0; gain = g;
        AudioStreamBuilder ob;
        ob.setDirection(Direction::Output); ob.setPerformanceMode(PerformanceMode::LowLatency);
        ob.setSharingMode(SharingMode::Exclusive); ob.setFormat(AudioFormat::Float);
        ob.setChannelCount(ChannelCount::Stereo); ob.setDeviceId(outId);
        ob.setDataCallback(this); ob.setErrorCallback(this);
        if (ob.openStream(out) != Result::OK) { out.reset(); return 1; }
        out->setBufferSizeInFrames(out->getFramesPerBurst() * 2);
        AudioStreamBuilder ib;
        ib.setDirection(Direction::Input); ib.setPerformanceMode(PerformanceMode::LowLatency);
        ib.setSharingMode(SharingMode::Exclusive); ib.setFormat(AudioFormat::Float);
        ib.setChannelCount(ChannelCount::Mono); ib.setDeviceId(inId);
        ib.setSampleRate(out->getSampleRate()); ib.setInputPreset(InputPreset::Unprocessed);
        unprocessed = true;
        if (ib.openStream(in) != Result::OK) {                // some devices refuse UNPROCESSED
            ib.setInputPreset(InputPreset::Generic); unprocessed = false;
            if (ib.openStream(in) != Result::OK) { out->close(); out.reset(); in.reset(); return 2; }
        }
        hp.highpass(float(out->getSampleRate()), 20.f);
        safety.configure(0.3f, 48, 1.0f, float(out->getSampleRate()));
        running = true;
        if (in->requestStart() != Result::OK || out->requestStart() != Result::OK) { stop(); return 3; }
        return 0;
    }
    void stop() {
        running = false;
        if (out) { out->requestStop(); out->close(); }
        if (in) { in->requestStop(); in->close(); }
        out.reset(); in.reset();
    }
    void fill(double* a) {
        for (int i = 0; i < 32; ++i) a[i] = -1;
        a[28] = NAN; a[29] = mode.load(); a[23] = nb.cal; a[24] = nb.sMag; a[25] = nb.sPhi * 180 / M_PI;
        a[26] = nb.calFreq; a[27] = nb.ancState; a[28] = nb.attDb(); a[30] = nb.weightMag(); a[31] = nb.baseAmp;               // -1 == "No medida"
        a[15] = safety.tripped ? 1 : 0; a[16] = safety.reason; a[17] = running ? 1 : 0; a[18] = fault ? 1 : 0;
        if (!out) return;
        a[0] = out->getSampleRate(); a[1] = out->getFramesPerBurst(); a[2] = out->getBufferSizeInFrames();
        a[3] = out->getChannelCount(); a[5] = out->getDeviceId();
        if (in) { a[4] = in->getChannelCount(); a[6] = in->getDeviceId(); a[14] = in->getSharingMode() == SharingMode::Exclusive; }
        auto lo = out->calculateLatencyMillis(); if (lo.error() == Result::OK) a[7] = lo.value();
        if (in) { auto li = in->calculateLatencyMillis(); if (li.error() == Result::OK) a[8] = li.value(); }
        auto xr = out->getXRunCount(); if (xr.error() == Result::OK) a[9] = xr.value();
        a[10] = double(inShort.load()); a[11] = double(safety.clipTotal); a[12] = double(inClip.load());
        a[13] = out->getSharingMode() == SharingMode::Exclusive; a[19] = rms.load(); a[20] = peak.load();
        a[21] = unprocessed; a[22] = out->getPerformanceMode() == PerformanceMode::LowLatency;
    }
};
static Engine gE;

// Offline FxLMS simulation. Pure math, no audio hardware. Returns attenuation in dB.
static double simulate(bool tonal, int pD, int sD, float mu) {
    const float fs = 48000; std::mt19937 rng(1); std::normal_distribution<float> nd(0, 0.1f);
    std::vector<float> P(64, 0.f), S(32, 0.f);
    P[pD] = 0.9f; P[pD + 3] = 0.3f; P[pD + 9] = -0.15f; S[sD] = 0.8f; S[sD + 1] = 0.4f; S[sD + 4] = -0.1f;
    std::vector<float> Sh = S; for (size_t i = 0; i < Sh.size(); ++i) Sh[i] *= 1 + 0.05f * (i % 2 ? 1 : -1);
    anc::Fir p, s; p.init(P.data(), 64); s.init(S.data(), 32);
    anc::FxLms f; f.init(128, Sh.data(), 32, mu);
    double sd = 0, se = 0; long N = 480000;
    for (long n = 0; n < N; ++n) {
        float t = n / fs;
        float x = tonal ? 0.02f * nd(rng) + 0.3f * std::sin(6.2831853f * 200 * t) + 0.15f * std::sin(6.2831853f * 440 * t) : nd(rng);
        float d = p.process(x), y = f.output(x), e = d + s.process(y);
        f.update(e);
        if (n > N - 96000) { sd += d * d; se += e * e; }
    }
    return 10 * std::log10(sd / (se + 1e-30));
}

extern "C" {
JNIEXPORT jint JNICALL Java_com_anclab_pro_NativeBridge_nativeStart(JNIEnv*, jobject, jint o, jint i, jfloat g) { return gE.start(o, i, g); }
JNIEXPORT void JNICALL Java_com_anclab_pro_NativeBridge_nativeStop(JNIEnv*, jobject) { gE.stop(); }
JNIEXPORT void JNICALL Java_com_anclab_pro_NativeBridge_nativeEmergencyStop(JNIEnv*, jobject) { gE.gain = 0.f; gE.safety.trip(9); gE.running = false; }
JNIEXPORT void JNICALL Java_com_anclab_pro_NativeBridge_nativeCommand(JNIEnv*, jobject, jint cmd, jfloat f) { gE.freq = f; gE.request = cmd; }
JNIEXPORT void JNICALL Java_com_anclab_pro_NativeBridge_nativeSetGain(JNIEnv*, jobject, jfloat g) { gE.gain = g < 0 ? 0 : (g > 0.25f ? 0.25f : g); }
JNIEXPORT jdoubleArray JNICALL Java_com_anclab_pro_NativeBridge_nativeStats(JNIEnv* env, jobject) {
    double a[32]; gE.fill(a); jdoubleArray r = env->NewDoubleArray(32); env->SetDoubleArrayRegion(r, 0, 32, a); return r; }
JNIEXPORT void JNICALL Java_com_anclab_pro_NativeBridge_nativeSnapshot(JNIEnv* env, jobject, jfloatArray arr) {
    float t[1024]; int p = gE.pos.load(); for (int i = 0; i < 1024; ++i) t[i] = gE.snap[(p + i) & 1023];
    env->SetFloatArrayRegion(arr, 0, 1024, t); }
JNIEXPORT jdouble JNICALL Java_com_anclab_pro_NativeBridge_nativeSimulate(JNIEnv*, jobject, jboolean tonal, jint pD, jint sD, jfloat mu) {
    return simulate(tonal, pD, sD, mu); }
}
