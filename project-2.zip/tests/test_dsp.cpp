// Host-side verification (no Android needed). Simulated acoustics, NOT a hardware test.
#include "../app/src/main/cpp/anc_dsp.h"
#include <cstdio>
#include <cstdlib>
#include <random>
using namespace anc;
static int fails = 0;
#define CHECK(c, msg) do { bool ok = (c); printf("  [%s] %s\n", ok ? "PASS" : "FAIL", msg); if (!ok) ++fails; } while (0)

// Run FxLMS on simulated plant. pDelay/sDelay in samples. Returns attenuation (dB) over last 2 s.
static double run(int pDelay, int sDelay, float mu, bool tonal, float shatErr, Safety* sf = nullptr, double secs = 10) {
    const float fs = 48000; std::mt19937 rng(1); std::normal_distribution<float> nd(0, 0.1f);
    std::vector<float> P(64, 0.f), S(32, 0.f);
    P[pDelay] = 0.9f; P[pDelay + 3] = 0.3f; P[pDelay + 9] = -0.15f;
    S[sDelay] = 0.8f; S[sDelay + 1] = 0.4f; S[sDelay + 4] = -0.1f;
    std::vector<float> Sh = S; for (size_t i = 0; i < Sh.size(); ++i) Sh[i] *= 1 + shatErr * (i % 2 ? 1 : -1);
    Fir p, s; p.init(P.data(), 64); s.init(S.data(), 32);
    FxLms f; f.init(128, Sh.data(), 32, mu);
    Safety local; Safety& sa = sf ? *sf : local; sa.configure(0.5f, 48, 1.0f, fs);
    double sd = 0, se = 0; long N = long(secs * fs);
    float yPrev = 0, ePrev = 0;
    for (long n = 0; n < N; ++n) {
        float t = n / fs;
        float x = nd(rng) * (tonal ? 0.2f : 1.f) + (tonal ? 0.3f * std::sin(2 * M_PI * 200 * t) + 0.15f * std::sin(2 * M_PI * 440 * t) : 0.f);
        float d = p.process(x);                  // noise arriving at error mic
        float y = sa.process(f.output(x));       // controller -> limiter -> speaker
        float e = d + s.process(y);              // residual at error mic (y*S added to d)
        sa.feedError(e); f.update(e); (void)yPrev; (void)ePrev;
        if (n > N - 2 * long(fs)) { sd += d * d; se += e * e; }
    }
    return 10 * std::log10(sd / (se + 1e-30));
}

int main() {
    puts("1) NLMS system identification (validates the adaptive core)");
    { std::mt19937 r(2); std::normal_distribution<float> nd(0, 1); float h[8] = {.5f,-.3f,.2f,.1f,0,0,-.05f,.02f};
      Fir plant; plant.init(h, 8); Nlms a; a.init(8, 0.5f); float e = 0;
      for (int n = 0; n < 20000; ++n) { float x = nd(r); a.process(x, plant.process(x), &e); }
      double err = 0; for (int i = 0; i < 8; ++i) err += std::fabs(a.w[i] - h[i]);
      printf("  coefficient abs error = %.2e\n", err); CHECK(err < 1e-3, "NLMS converges to true filter"); }

    puts("2) FxLMS, tonal noise, primary path faster than secondary (causal case)");
    { double a = run(10, 3, 0.02f, true, 0.05f); printf("  attenuation = %.1f dB\n", a); CHECK(a > 15, "tones attenuated >15 dB with 5%% path-model error"); }

    puts("3) FxLMS, broadband noise, causal");
    { double a = run(20, 3, 0.02f, false, 0.05f); printf("  attenuation = %.1f dB\n", a); CHECK(a > 6, "broadband attenuated >6 dB"); }

    puts("4) Latency penalty: secondary path slower than primary (non-causal)");
    { double a = run(2, 30 - 5, 0.02f, false, 0.0f); printf("  attenuation = %.1f dB\n", a);
      double b = run(20, 3, 0.02f, false, 0.0f); printf("  causal reference  = %.1f dB\n", b);
      CHECK(a < b - 3, "broadband ANC degrades when total latency exceeds acoustic delay"); }

    puts("5) Safety: step size far too large must trip, not blast the output");
    { Safety sf; double a = run(10, 3, 1.9f, false, 0.3f, &sf, 5);
      printf("  tripped=%d reason=%d clips=%llu (att %.1f dB)\n", sf.tripped, sf.reason, (unsigned long long)sf.clipTotal, a);
      CHECK(sf.tripped || a > 0, "instability caught by Safety or output stays bounded"); }

    puts("6) Safety: NaN and sustained clipping");
    { Safety s; s.configure(0.3f, 10, 1.f, 48000); CHECK(s.process(NAN) == 0 && s.tripped && s.reason == 1, "NaN trips");
      s.reset(); float o = 0; for (int i = 0; i < 20; ++i) o = s.process(5.f);
      CHECK(s.tripped && s.reason == 2 && o == 0, "sustained clipping trips and mutes");
      s.reset(); CHECK(std::fabs(s.process(5.f) - 0.3f) < 1e-6, "limiter clamps to maxOut"); }

    printf("\n%s (%d failure(s))\n", fails ? "FAILED" : "ALL PASSED", fails); return fails;
}
